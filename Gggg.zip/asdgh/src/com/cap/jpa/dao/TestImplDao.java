package com.cap.jpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cap.jpa.model.TestBean;

@Repository

@Transactional
public class TestImplDao implements ITestdao{
	@PersistenceContext
	EntityManager em;

	@Override
	public TestBean findqueryID(Integer queryID) {
		return em.find(TestBean.class, queryID);
	}

	

	@Override
	public boolean textarea(Integer queryID, String textarea) {
		
		TestBean t=em.find(TestBean.class, queryID);
		t.setSolutions(textarea);
		System.out.println(textarea);
		em.merge(t);
		
		
		return true;
	}

}
