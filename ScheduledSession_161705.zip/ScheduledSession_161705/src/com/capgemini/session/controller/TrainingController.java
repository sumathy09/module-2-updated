package com.capgemini.session.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.session.model.ScheduledSessions;
import com.capgemini.session.service.ITrainingService;

  
 
@Controller
public class TrainingController {
@Autowired
ITrainingService service;
@RequestMapping("/home")
public String displaydetails(Model model){
	String view="ScheduledSessions";
	ArrayList<ScheduledSessions> list=service.getAllDetails();
	model.addAttribute("session",list);
	return view;
}
/*@RequestMapping("/enroll")
public String enrollPage(Model model){
	String view="success";
	 String sessionName=service.getSessionName();
	model.addAttribute("sessionName",sessionName);
	return view;
}*/
@RequestMapping("/enroll")
public ModelAndView enrollPage(@RequestParam(value="sessionName") String name ){
	return new ModelAndView("success","sessionName", name);
}
}



 

 