package com.capgemini.session.service;

import java.util.ArrayList;

 
import com.capgemini.session.model.ScheduledSessions;

 

public interface ITrainingService {
	public ArrayList<ScheduledSessions> getAllDetails();
	/*public String getSessionName();*/
}
