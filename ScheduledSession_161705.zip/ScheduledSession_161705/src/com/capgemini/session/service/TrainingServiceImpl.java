package com.capgemini.session.service;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.capgemini.session.dao.ITrainingDAO;
import com.capgemini.session.model.ScheduledSessions;

@Service
@Transactional
public class TrainingServiceImpl implements ITrainingService {
 @Autowired
 ITrainingDAO sessionDAO;
	@Override
	public ArrayList<ScheduledSessions> getAllDetails() {
		 
		return sessionDAO.getAllDetails();
	}

	/*@Override
	public String getSessionName() {
		 
		return sessionDAO.getSessionName();
	}*/

}