package com.capgemini.session.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

 
import com.capgemini.session.model.ScheduledSessions;
@Repository 
public class TrainingDAOImpl implements ITrainingDAO {
	@PersistenceContext
	EntityManager manager;
	@Override
	public ArrayList<ScheduledSessions> getAllDetails() {
		 
		ArrayList<ScheduledSessions> list = new ArrayList<>();
		String jpql = "Select session from ScheduledSessions session ";
		TypedQuery<ScheduledSessions> query = manager.createQuery(jpql,  ScheduledSessions.class);
		list = (ArrayList<ScheduledSessions>) query.getResultList();
		return list;
	}

	/*@Override
	public String getSessionName() {
		String jpql ="Select session.name from ScheduledSessions session where session.id = 1";
		TypedQuery<String> query = manager.createQuery(jpql,String.class);
		String sessionName = query.getSingleResult();
		return sessionName; 
	}*/

	 
	 
}


 