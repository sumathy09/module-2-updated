package com.capgemini.session.dao;

import java.util.ArrayList;

 
import com.capgemini.session.model.ScheduledSessions;

 

public interface ITrainingDAO {
	public ArrayList<ScheduledSessions> getAllDetails();
	/*public String getSessionName();*/
}
