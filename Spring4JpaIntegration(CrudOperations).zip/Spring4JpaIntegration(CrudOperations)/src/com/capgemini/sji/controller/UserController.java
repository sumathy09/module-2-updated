package com.capgemini.sji.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.sji.entity.UserEntity;
import com.capgemini.sji.exception.UserException;
import com.capgemini.sji.model.User;
import com.capgemini.sji.service.IUserService;

import java.util.List;

@Controller
@RequestMapping(value="/userc")
public class UserController {
	@Autowired
	private IUserService userService;
	
@RequestMapping(value="/newuser",method=RequestMethod.GET)

	public ModelAndView showUserForm() {
		return new ModelAndView("add_user","user",new User());
	}
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public ModelAndView processForm( @Valid @ModelAttribute("user") User user,
			BindingResult result){
		
		try {
			if(result.hasErrors()) {
				List<ObjectError> errorList=result.getAllErrors();
				System.out.println(errorList);
				return new ModelAndView("add_user","user",new User());
			}else {
				System.out.println(user.getUsername()+","+user.getBirthdate());
				//persist into database, call service class method
				com.capgemini.sji.entity.UserEntity userE=new com.capgemini.sji.entity.UserEntity();
				populateUserE(userE,user);
				Integer n=userService.addUserDetails(userE);
				if(n>0)
				{
				return new ModelAndView("status","status","User added to database");
				}
				else
				{
				return new ModelAndView("status","status","Unable to add user to database");	
				}
			}
		} catch (Exception e) {			
			return new ModelAndView("status","status",e.getMessage()); 
		}		
		
	}

	private void populateUserE(com.capgemini.sji.entity.UserEntity userE, User user) {
		
		userE.setUsername(user.getUsername());
		userE.setPassword(user.getPassword());
		userE.setEmailId(user.getEmailId());
		userE.setBirthdate(user.getBirthdate());
	}
	
	
	
	
	
	@RequestMapping(value="/allusers", method=RequestMethod.GET)
	public ModelAndView getAllCustomerDetails() {
		try {
			List<User> userList=userService.getAllUserDetails();
			if(userList.size()!=0) {				
				return new ModelAndView("all_users","userList",userList);
			}else {
				return new ModelAndView("status","status","No users in database");
			}
		}catch(UserException e) {
			e.printStackTrace();
			return new ModelAndView("status","status",e.getMessage());
		}
	}
	
	
	
	
	
	
	
	@RequestMapping(value="/deleteuser", method=RequestMethod.GET)
	public ModelAndView deleteCustomer(@RequestParam(value="userid") Integer userid) {
		try {
			//int id=2;
			int n= userService.deleteCustomer(userid);
			if(n>0) {
				return new ModelAndView("cust_status","message","Customer Record Deleted");
			}else {
				return new ModelAndView("cust_status","message","Unable to Delete Customer Record");
			}
		}catch(UserException e) {
			return new ModelAndView("status","status",e.getMessage());
		}
	}
	
	@RequestMapping(value="/edituser", method=RequestMethod.GET)
	public ModelAndView preUpdateCustomer(@RequestParam(value="userid") Integer userid) {
		try {
			
			User user=userService.getUserById(userid);
			return new ModelAndView("update_customer","user",user);
		}catch(UserException e) {
			return new ModelAndView("status","message",e.getMessage());
		}catch(Exception e) {
			return new ModelAndView("status","message",e.getMessage());
		}
	}
	
	@RequestMapping(value="/updateuser", method=RequestMethod.POST)
	public ModelAndView postUpdateCustomer(@ModelAttribute(value="user") User user,@ModelAttribute(value="userid") Integer userid) {
		try {
			//System.out.println(customer.getCustomerName());
			System.out.println(userid+"\n"+user);
			int n=userService.updateCustomer(user);
			if(n>0) {
				return new ModelAndView("cust_status","message","CUSTOMER_UPDATE SUCCESS");
			}else {
				return new ModelAndView("cust_status","message","CUSTOMER_UPDATE FAIL");
			}
		}catch(UserException e) {
			return new ModelAndView("status","message",e.getMessage());
		}
	}
	
	
	
	
	
	
	
	
	
	
}
