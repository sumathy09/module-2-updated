package com.capgemini.sji.dao;

import java.util.List;

import com.capgemini.sji.entity.UserEntity;
import com.capgemini.sji.exception.UserException;

public interface IUserDAO {
	public abstract UserEntity getUserDetails(Integer userid) 
			throws UserException;
	public abstract Boolean isValidUser(String username,String password) 
			throws UserException;
	public abstract Integer addUserDetails(UserEntity user) 
			throws UserException;
	public abstract List<UserEntity> getAlluserDetails() throws UserException;
	public abstract int deleteCustomer(int id) throws UserException;
	Integer updateCustomer(UserEntity user) throws UserException;
	UserEntity getUserById(Integer ID) throws UserException;
	
}
