package com.capgemini.sji.service;

import java.util.List;

import com.capgemini.sji.entity.UserEntity;
import com.capgemini.sji.exception.UserException;
import com.capgemini.sji.model.User;

public interface IUserService {
	public abstract UserEntity getUserDetails(Integer userid) 
			throws UserException;
	public abstract Boolean isValidUser(String username,String password) 
			throws UserException;
	public abstract Integer addUserDetails(UserEntity user) 
			throws UserException;
	public abstract List<User> getAllUserDetails() throws UserException;
	public abstract int deleteCustomer(int id) throws UserException;
	Integer updateCustomer(User user) throws UserException;
	User getUserById(Integer ID) throws UserException;
}
