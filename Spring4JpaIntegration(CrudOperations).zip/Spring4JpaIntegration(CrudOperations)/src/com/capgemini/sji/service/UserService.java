package com.capgemini.sji.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.sji.dao.IUserDAO;
import com.capgemini.sji.dao.UserDao;
import com.capgemini.sji.entity.UserEntity;
import com.capgemini.sji.exception.UserException;
import com.capgemini.sji.model.User;




@Service
@Transactional
public class UserService implements IUserService{
// tight coupling	
//	private IUserDAO userDAO=new UserDao();
// loose coupling through DI
	@Autowired
	private IUserDAO userDAO;
	@Override
	public UserEntity getUserDetails(Integer userid) throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean isValidUser(String username, String password) throws UserException {
			return userDAO.isValidUser(username, password);
	}

	@Override
	public Integer addUserDetails(UserEntity user) throws UserException {
		// TODO Auto-generated method stub
		return userDAO.addUserDetails(user);
	}
	
	
	@Override
	public List<User> getAllUserDetails() throws UserException {
		try {
			List<UserEntity> userEntityList=userDAO.getAlluserDetails();
			//System.out.println(customerEntityList.size());
			
			if(userEntityList !=null) {
				List<User> userList=new ArrayList<>();				
				populateCustomerList(userList,userEntityList);
				return userList;
			}
			throw new UserException("Customer List is empty");
		}catch(Exception e) {
			e.printStackTrace();
			throw new UserException(e.getMessage());
		}
		
	}


	private void populateCustomerList(List<User> userList,List<UserEntity> userEntityList) {
		Iterator<UserEntity> iterator= userEntityList.iterator();		
		while(iterator.hasNext()) {
			User user=new User();
			populateUser(user,iterator.next());
			userList.add(user);		
		}
		
	}
	
	
	private void populateUser(User user, UserEntity next) {
		user.setUserid(next.getUserid());
		user.setUsername(next.getUsername());
		user.setPassword(next.getPassword());
		user.setBirthdate(next.getBirthdate());
		user.setEmailId(next.getEmailId());		
	}

	@Override
	public int deleteCustomer(int id) throws UserException {
		return userDAO.deleteCustomer(id);
	}
	
	
	@Override
	public User getUserById(Integer ID) throws UserException {
		UserEntity userEntity=userDAO.getUserById(ID);
		if(userEntity!=null) {
			User user=new User();
			populateUser(user,userEntity);
			return user;
		}
		return null;
	}
	
	
	@Override
	public Integer updateCustomer(User user) throws UserException {
		UserEntity userEntity=new UserEntity();
		populateUserEntity(user,userEntity);
		return userDAO.updateCustomer(userEntity);
	}

	private void populateUserEntity(User next, UserEntity user) {
		user.setUserid(next.getUserid());
		user.setUsername(next.getUsername());
		user.setPassword(next.getPassword());
		user.setBirthdate(next.getBirthdate());
		user.setEmailId(next.getEmailId());		
	}
}
