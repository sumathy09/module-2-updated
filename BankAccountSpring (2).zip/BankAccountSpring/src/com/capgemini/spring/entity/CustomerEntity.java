package com.capgemini.spring.entity;
 
 
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
 
@Table(name="customer_entity")
@Entity
//static query
/*@NamedQueries(
		  {
@NamedQuery(name="q1",query="select e from customer_entity e")}
//@NamedQuery(name="q2",query="select e from customer_entity e where e.salary>50000.00")}
)*/
public class CustomerEntity {
	@Id
	private Integer accNo;
	private Integer pin;
	private String name;
	private String phoneNo;
	private String address;
	private String aathar;
    private double balance;
    private String birthDate;
    private String emailId;
    
    @OneToMany(mappedBy="cus",cascade=CascadeType.ALL)
   	private List<TransactionEntity> customer = new ArrayList<TransactionEntity>();
  
    public List<TransactionEntity> getCustomer() {
   		return customer;
   	}

   	public void setCustomer(List<TransactionEntity> customer) {
   		this.customer = customer;
   	}
     

	public Integer getPin() {
		return pin;
	}

	public void setPin(Integer pin) {
		pin = (int) (Math.random() * 7000);
		this.pin = pin;
	}

	public CustomerEntity() {
		super();
		 
	}

	 

	public CustomerEntity(Integer accNo, Integer pin, String name,
			String phoneNo, String address, String aathar, Double balance,
			String birthDate, String emailId, List<TransactionEntity> customer) {
		super();
		this.accNo = accNo;
		this.pin = pin;
		this.name = name;
		this.phoneNo = phoneNo;
		this.address = address;
		this.aathar = aathar;
		this.balance = balance;
		this.birthDate = birthDate;
		this.emailId = emailId;
		this.customer = customer;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
 
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAathar() {
		return aathar;
	}

	public void setAathar(String aathar) {
		this.aathar = aathar;
	}

	 
	public Integer getAccNo() {
		return accNo;
	}

	public void setAccNo(Integer accNo) {
		accNo = (int) (Math.random() * 700000);
		this.accNo = accNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "CustomerEntity [accNo=" + accNo + ", pin=" + pin + ", name="
				+ name + ", phoneNo=" + phoneNo + ", address=" + address
				+ ", aathar=" + aathar + ", balance=" + balance
				+ ", birthDate=" + birthDate + ", emailId=" + emailId
				+ " ]";
	}

	 
	

}



 