package com.capgemini.spring.service;
 
import java.util.List;

import com.capgemini.spring.entity.CustomerEntity;
import com.capgemini.spring.exception.CustomerException;
import com.capgemini.spring.model.Customer;
 
 

public interface IBankService {
	  Integer createAccount(CustomerEntity cust)  throws CustomerException ;
	  public abstract List<Customer> getAllUserDetails() throws CustomerException;
	  double showBalance(Integer accNo,Integer pin)throws CustomerException;
	  Integer validAccount(Integer id)throws CustomerException;
	  Integer validPin(Integer pin)throws CustomerException;
	  double deposit(Integer accNo,double deposit)throws CustomerException;
	 double withdraw(Integer accNo,double withdraw)throws CustomerException;
	 
	CustomerEntity getUserById(Integer id,Integer pin) throws CustomerException;
}
