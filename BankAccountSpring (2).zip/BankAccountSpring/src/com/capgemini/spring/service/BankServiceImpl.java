 package com.capgemini.spring.service;
 
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.spring.dao.BankDAOImpl;
import com.capgemini.spring.dao.IBankDAO;
import com.capgemini.spring.entity.CustomerEntity;
import com.capgemini.spring.exception.CustomerException;
import com.capgemini.spring.model.Customer;
 
 
@Service
@Transactional
public class BankServiceImpl implements IBankService {
	@Autowired
     IBankDAO bankDAO;
 
	@Override
    public Integer createAccount(CustomerEntity cust)  throws CustomerException  {
       
		return bankDAO.createAccount(cust);
    }


	@Override
	public List<Customer> getAllUserDetails() throws CustomerException {
		try {
			List<CustomerEntity> customerEList=bankDAO.getAlluserDetails();
			//System.out.println(customerEntityList.size());
			
			if(customerEList !=null) {
				List<Customer> userList=new ArrayList<>();				
				populateCustomerList(userList,customerEList);
				return userList;
			}
			throw new CustomerException("Customer List is empty");
		}catch(Exception e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}
		 
	}
	
	private void populateCustomerList(List<Customer> customerList,List<CustomerEntity> customerEntityList) {
		Iterator<CustomerEntity> iterator= customerEntityList.iterator();		
		while(iterator.hasNext()) {
			Customer customer=new Customer();
			populateUser(customer,iterator.next());
			customerList.add(customer);		
		}
		
	}

	private void populateUser(Customer cust, CustomerEntity customer) {
		 cust.setName(customer.getName());
		 cust.setAathar(customer.getAathar());
		 cust.setAddress(customer.getAddress());
		 cust.setBirthDate(customer.getBirthDate());
		 cust.setBalance(customer.getBalance());
		 cust.setEmailId(customer.getEmailId());
		 cust.setPhoneNo(customer.getPhoneNo());
		 cust.setAccNo(customer.getAccNo());
		 
	}


	@Override
	public double showBalance(Integer accNo,Integer pin) throws CustomerException {
		 
		return bankDAO.showBalance(accNo,pin);
	}


	@Override
	public Integer validAccount(Integer id) throws CustomerException {
		// TODO Auto-generated method stub
		return bankDAO.validAccount(id);
	}


	@Override
	public Integer validPin(Integer pin) throws CustomerException {
		// TODO Auto-generated method stub
		return bankDAO.validPin(pin);
	}


	@Override
	public double deposit(Integer accNo, double deposit)
			throws CustomerException {
		 
		return bankDAO.deposit(accNo, deposit);
	}


	@Override
	public double withdraw(Integer accNo, double withdraw)
			throws CustomerException {
		 
		return  bankDAO.withdraw(accNo, withdraw);
	}


	@Override
	public CustomerEntity getUserById(Integer id,Integer pin) throws CustomerException {
		 
		return bankDAO.getUserById(id,pin);
	}

    
}



 