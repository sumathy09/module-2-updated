package com.capgemini.spring.model;

public class Customer {
 
	private Integer accNo;
	private Integer pin;
	private String name;
	private String phoneNo;
	private String address;
	private String aathar;
    private double balance;
    private String birthDate;
    private String emailId;
	 
    public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

    public Customer(Integer accNo, Integer pin, String name, String phoneNo,
			String address, String aathar, double balance, String birthDate,
			String emailId) {
		super();
		this.accNo = accNo;
		this.pin = pin;
		this.name = name;
		this.phoneNo = phoneNo;
		this.address = address;
		this.aathar = aathar;
		this.balance = balance;
		this.birthDate = birthDate;
		this.emailId = emailId;
	}


	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
 
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAathar() {
		return aathar;
	}

	public void setAathar(String aathar) {
		this.aathar = aathar;
	}
	public Integer getPin() {
		return pin;
	}

	public void setPin(Integer pin) {
		this.pin = pin;
	}

	public Integer getAccNo() {
		return accNo;
	}

	public void setAccNo(Integer accNo) {
		this.accNo = accNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [accNo=" + accNo + ", pin=" + pin + ", name=" + name
				+ ", phoneNo=" + phoneNo + ", address=" + address + ", aathar="
				+ aathar + ", balance=" + balance + ", birthDate=" + birthDate
				+ ", emailId=" + emailId + "]";
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	 
	
}
